create database Truyum;
use Truyum;
show tables;

create table Menu_Item
(
Menu_Item int auto_increment primary key,
Name varchar(100),
Price decimal(7,2),
Active varchar(10),
Date_Of_Launch datetime,
Category varchar(50),
Free_Delivery varchar(10)
);
create table User_Details
(
User_Id int auto_increment primary key,
User_Name varchar(50)
);
create table Cart
(
Cart_Id int auto_increment primary key,
User_Id int,
Menu_Item_Id int,
constraint fk_Cart_User_Id foreign key (User_Id) references User_Details(User_Id),
constraint fk_Cart_Menu_Item_Id foreign key (Menu_Item_Id) references Menu_Item(Menu_Item_Id)
);
insert into User_Details (User_Name) values('Carl'),('Zen');
insert into Menu_Item (Name,Price,Date_Of_Launch,Category,Free_Delivery)values('Sandwich',99.00,'Yes','2017/03/15','Main Course','Yes');
insert into Menu_Item (Name,Price,Date_Of_Launch,Category,Free_Delivery)values('Burger',129.00,'Yes','2017/12/15','Main Course','No');
insert into Menu_Item (Name,Price,Date_Of_Launch,Category,Free_Delivery)values('Pizza',149.00,'Yes','2017/03/21','Main Course','No');
insert into Menu_Item (Name,Price,Date_Of_Launch,Category,Free_Delivery)values('French Fries',57.00,'No','2017/03/15','Starters','Yes');
insert into Menu_Item (Name,Price,Date_Of_Launch,Category,Free_Delivery)values('Chocolate Brownie',32.00,'Yes','2017/03/15','Dessert','Yes');

-- 1.  View Menu Item List Admin
select Name, concat('Rs.',Price) as 'Price',
Active, Date_Of_Launch, Category, Free_Delivery from Menu_Item;

-- 2. View Menu Item List Customer
select Name, Free_Delivery, concat('Rs.','Price') as Price,
Category from Menu_Item where Date_Of_Launch() and Active*'Yes';


-- 3.  Edit Menu Item
select Name, concat('Rs.',Price) as 'Price', Active,
Date_Of_Launch, Category, Free_Delivery from Menu_Item where Menu_Item_Id=1;

update Menu_Item set Price='100.00' where Menu_Item_Id=1;

-- 4.  Add to Cart
insert into Cart(User_Id,Menu_Item_Id) values(2,1),(2,2),(2,3);

-- 5 .
-- a.
select Name,Free_Delivery, concat('Rs.',Price) as 'Price'
from Menu_Item M
inner join Cart C
on M.Menu_Item_Id = C.Menu_Item_Id
inner join User_Details UD
on C.User_Id = UD.User_Id
where C.User_Id=2;

-- b.
select concat('Rs.',cast(sum(Price)as char )) as 'Total'
from Menu_Item M
inner join Cart C 
on M.Menu_Item_Id = C.Menu_Item_Id
inner join User_Details UD
on C.User_Id = UD.User_Id
where C.User_Id=2;

-- 6.
delete from Cart
where User_Id=2 and Menu_Item_Id=1;

